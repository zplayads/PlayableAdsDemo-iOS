//
//  AtmosplayAdsBanner.h
//  PlayableAds
//
//  Created by 王泽永 on 2019/9/4.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

/// Represents the fixed banner ad size
typedef NS_ENUM(NSUInteger, AtmosplayAdsBannerSize) {
    /// iPhone and iPod Touch ad size. Typically 320x50.
    kAtmosplayAdsBanner320x50 = 1 << 0,
    /// Leaderboard size for the iPad. Typically 728x90.
    kAtmosplayAdsBanner728x90 = 1 << 1,
    /// An ad size that spans the full width of the application in portrait orientation. The height is
    /// typically 50 pixels on an iPhone/iPod UI, and 90 pixels tall on an iPad UI.
    kAtmosplayAdsSmartBannerPortrait = 1 << 3,
    /// An ad size that spans the full width of the application in landscape orientation. The height is
    /// typically 32 pixels on an iPhone/iPod UI, and 90 pixels tall on an iPad UI.
    kAtmosplayAdsSmartBannerLandscape = 1 << 4
};

@class AtmosplayAdsBanner;
@protocol AtmosplayAdsBannerDelegate <NSObject>
@optional
/// Tells the delegate that an ad has been successfully loaded.
- (void)atmosplayAdsBannerViewDidLoad:(AtmosplayAdsBanner *)bannerView;

/// Tells the delegate that a request failed.
- (void)atmosplayAdsBannerView:(AtmosplayAdsBanner *)bannerView didFailWithError:(NSError *)error;

/// Tells the delegate that the banner view has been clicked.
- (void)atmosplayAdsBannerViewDidClick:(AtmosplayAdsBanner *)bannerView;

@end
@interface AtmosplayAdsBanner : UIView

/// Required to set this banner view to a proper size. Use one of the predefined standard ad sizes (such as
/// kAtmosplayAdsBanner320x50) If you want to specify the ad size you need to set it before calling loadAd:
/// default: iPhone and iPod Touch ad size. Typically 320x50.
/// default: iPad ad size. Typically 728x90.
@property (nonatomic, assign) AtmosplayAdsBannerSize bannerSize;

/// Optional delegate object that receives state change notifications.
@property (nonatomic, weak, nullable) id<AtmosplayAdsBannerDelegate> delegate;

@property (nonatomic) NSString *channelID;

+ (instancetype) new NS_UNAVAILABLE;
- (instancetype)init NS_UNAVAILABLE;
- (instancetype)initWithFrame:(CGRect)frame NS_UNAVAILABLE;

/// Initializes and returns a banner view.
- (instancetype)initWithAdUnitID:(NSString *)adUnitID
                           appID:(NSString *)appID
              rootViewController:(UIViewController *)rootViewController;

/// Begins loading the AtmosplayAdsBanner content.
- (void)loadAd;

@end

NS_ASSUME_NONNULL_END
