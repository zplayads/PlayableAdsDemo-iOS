//
//  PlayableAdsGDPR.h
//  Pods
//
//  Created by 王泽永 on 2019/5/28.
//

#import <Foundation/Foundation.h>

typedef enum : NSUInteger {
    /// The user has granted consent for personalized ads.
    PlayableAdsConsentStatusPersonalized,
    /// The user has granted consent for non-personalized ads.
    PlayableAdsConsentStatusNonPersonalized,
    /// The user has neither granted nor declined consent for personalized or non-personalized ads.
    PlayableAdsConsentStatusUnknown,
} PlayableAdsConsentStatus;

NS_ASSUME_NONNULL_BEGIN

@interface PlayableAdsGDPR : NSObject
/// Returns the consent status that you set.
@property (nonatomic, assign, readonly, getter=getConsentStatus) PlayableAdsConsentStatus consentStatus;

/// returns the shared PlayableAdsGDPR instance.
+ (instancetype)sharedGDPRManager;

/// update PlayableAdsGDPR consent status.
/// consent: Your user's consent string. Default is the user has given consent to store and process personal
/// information.
- (void)updatePlayableAdsConsentStatus:(PlayableAdsConsentStatus)consent;
@end

NS_ASSUME_NONNULL_END
